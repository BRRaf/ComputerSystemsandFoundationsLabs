#ifndef main_h
#define main_h

#include <stdio.h>

typedef struct student{
  char* name;
  double grade;
} student;

float averagef(int list[], int size);

float* averageh(int list[], int size);


#endif /* main_h */
