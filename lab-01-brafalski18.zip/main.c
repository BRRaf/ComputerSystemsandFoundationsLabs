#include <stdio.h>
#include "mainf.h"

int main(void) {
  
// asking the user to input an array size  
printf("Hello user, how many values would you like to input? \n");

int list_size;

scanf("%d", &list_size);


//creating the array
int array1[list_size];

int value;
float sum = 0;

//filling the array with user inputed values
for(int i = 0; i <= list_size - 1; i++){

printf("please input a value for array value %d \n", i);

scanf("%d", &value);

array1[i] = value;

sum += value;

}

//manually calculating average
 printf("the size is %d \n", list_size);
  printf("the size is %d \n", sum);

float average = sum/list_size;

printf("The average of the inputed list is %f \n", average);
printf("\n");

//using function 1 to calculate average
average = averagef(array1, list_size);

printf("The average of the inputed list using the function is %f \n", average);
printf("\n");

//using function 2 to calculate average
int* p_ave = averageh(array1, list_size);

average = *p_ave;

printf("The average of the inputed list using the pass by reference function is %f \n", average);

// creating a space in the heap for an array
int* malarray = (int*)malloc(sizeof(array1));

//filling that malloced space with integers
for(int k = 0; k <= list_size - 1; k++){
  malarray[k] = array1[k];
}

//calculating average of heap array using a function 
average = averagef(malarray, list_size);

printf("The average of the malloc array is %f \n", average);
printf("\n");

//creating a student struct and filling their values
student s1;

s1.grade = 80.5;
s1.name = "Ben";

printf("The name of the student in stack is %s and their grade is %f \n", s1.name, s1.grade);

printf("\n");

//creating a student struct in the heap
student* s_ptr = (student*)malloc(sizeof(student));
(*s_ptr).name = "MBen";
(*s_ptr).grade = 85.9;

printf("The name of the student in the heap is %s and their grade is %f \n", (*s_ptr).name, (*s_ptr).grade);


//freeing allocated values
free(s_ptr);
free(malarray);
  return 0;
}

