
#include "mainf.h"

//this function takes an array and a int size for the array to calculate the function for the array
float averagef(int list[], int size) {

  

  float ave;

  float asum = 0;


  for(int i = 0; i <= size - 1; i++){

    asum += list[i];
   printf("the array value is %d \n", list[i]);
  }



  ave = asum/size;

    return ave;
}


// function returns a point from a calculated average made from an array and list size
float* averageh(int list[], int size) {

float hsum = 0;

  for(int i = 0; i <= size - 1; i++){

    hsum += list[i];
   printf("the array value is %d \n", list[i]);
  }

   printf("the f size is %d \n", size);

float ave = hsum/size;

float* p_ave = &ave;



  return p_ave;
}


