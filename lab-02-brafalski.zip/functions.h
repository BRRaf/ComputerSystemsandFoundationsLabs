

#include <stdio.h>

// A node that contains a single integer, a pointer to the node connected above it and below it
typedef struct double_linked_list_node{

int number;
struct double_linked_list_node* previous_node;
struct double_linked_list_node* next_node;

} double_linked_list_node;




// a struct that contains the head node connected to the rest of the list
typedef struct double_linked_list{

double_linked_list_node* head_node;

} double_linked_list;


// A struct contains a list that only manipulates the top of the list
typedef struct stack{
int size;

double_linked_list_node* head_node;

} stack;


// A struct that contains a list of nodes that only manipulates the top and bottom of the list
typedef struct queue{

int size;

double_linked_list_node* top_node;
double_linked_list_node* tail_node;


} queue;


// getting the total number of nodes in the list
int get_size(double_linked_list* l);

// returning a node with a matching integer
double_linked_list_node* search_node(int find, double_linked_list* l);
// putting a node at the end of the list
int insert_node(int element, double_linked_list* l);
// freeing a node with a matching int
int delete_node(int value, double_linked_list* l);


//-----------------------------

//The Stack 


// creating a stat with a matching amount of nodes and the input
stack* create_stack(int s);

// getting the head node in a stack
double_linked_list_node* get_stack_top(stack* s);

//removing the top element and moving the head node down the list
void pop(stack* s);

// putting a new element as the head node
void push(stack* s, int element);


//-------------------------------------
//The Queue

//creating a new queue with a matching number of nodes as the inputed int
queue* create_queue(int s);

//getting the head node of the queue
double_linked_list_node* get_queue_top(queue* q);

//removing the top node and shifting the head node down the list
void queue_pop(queue* q);

//adding a new element to the end of the list, shifting the tail node
void queue_push(queue* q, int element);