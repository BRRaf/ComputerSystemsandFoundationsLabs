#include <stdio.h>
#include "functions.h"
#include <stdlib.h>



int main(void) {

  double_linked_list* l = (double_linked_list*)malloc(sizeof(double_linked_list));

  double_linked_list_node* n = (double_linked_list_node*)malloc(sizeof(double_linked_list_node));



  insert_node(1, l);

  n = search_node(1, l);

  printf("the number in node 1 is %d \n", n->number);

  insert_node(2, l);

  insert_node(3, l);

  int size = get_size(l); 
 
  printf("the size of the list is %d \n", size);

  n = search_node(2,l);

  printf("the value inside the second node in list l is %d \n", n->number );

  delete_node(1, l);

  search_node(1,l);

  printf("------------------------------------------------ stack tests \n");

  stack* s = create_stack(5);

  n = get_stack_top(s);

  printf("The integer at the top of the stack is %d \n", n->number);

  pop(s);

  n = get_stack_top(s);

  printf("The integer at the top of the stack is %d \n", n->number);

  push(s,1);

  n = get_stack_top(s);

  printf("The integer at the top of the stack is %d \n", n->number);

  printf("------------------------------------------------ queue tests \n");

  queue* q = create_queue(5);

  n = get_queue_top(q);

  printf("The integer at the top of the queue is %d \n", n->number);

  queue_pop(q);

  n = get_queue_top(q);

  printf("The integer at the top of the queue is %d \n", n->number);

  queue_push(q, 9);

  n = get_queue_top(q);

  printf("the integer at the end of the q is %d", q->tail_node->number);





  delete_node(2, l);
  delete_node(3, l);


  free(n);
  free(l);
  free(s);
  free(q);

  return 0;
}