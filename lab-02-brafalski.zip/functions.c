#include "functions.h"
#include <stdlib.h>
#include <stdio.h>

// mallocing a space in the heap for a node and returning the pointer
int insert_node(int element, double_linked_list* l){

  double_linked_list_node* n = (struct double_linked_list_node*)malloc(sizeof(double_linked_list_node));
  n->number = element;
  n->next_node = NULL;

  double_linked_list_node* p;  // keeping track of the previous node


  if(l->head_node == NULL){

    printf("inserted into first slot \n");
    l->head_node = n;

    }else if(l->head_node->next_node == NULL){
      printf("inserted into slot 2 \n");
      l->head_node->next_node = n;
      l->head_node->next_node->previous_node = l->head_node;

      }else{

        printf("inserted into other slot \n");
        p = l->head_node;
    
        while(p->next_node != NULL){
          p = p->next_node;
        }

      p->next_node = n;
      n->previous_node = p;
    
      }
  return 0;
}

//----------------------------------------





// the function takes a list and goes through it to find the matching integer to the node and returns it, returning null if not found  
double_linked_list_node* search_node(int find, double_linked_list* l){
  
  if(!l || !l->head_node){
    return NULL;
  }

  int element;
  double_linked_list_node* search = l->head_node;

  if(search->number==find){
    return search;
  }

  while(search->next_node != NULL){
    if(search->number != find){
      search = search->next_node;

    }else if(search->number == find){
        return search;
    }
  }

  printf("couldn't find inputed value in any node \n");
    return NULL;

}


//takes a node a frees it from the heap

int delete_node(int value, double_linked_list* l){

  double_linked_list_node* temp; 

  if(l->head_node != NULL){
    temp = l->head_node;
  }else{

  printf("The node that has the matching integer was not found and nothing was deleted or changed \n");

  return 0;
}


  int match = temp->number;



  while(value != match){
    if(temp->next_node == NULL){
        printf("The node that has the matching integer was not found and nothing was deleted or changed \n");
        return 0;
      }

      temp = temp->next_node;

      match = temp->number;

  }

  if(temp->next_node != NULL){
   temp->number = temp->next_node->number;
   temp = temp->next_node;
  }

  

  while(temp->next_node != NULL){

      temp->previous_node = temp;

      temp->number = temp->next_node->number;
      
      temp = temp->next_node;


  }

  free(temp);
  return 0;
}


//returns the size of the list
int get_size(double_linked_list* l){

  int size = 0;

  double_linked_list_node* n = l->head_node;

  while(n != NULL){

    size += 1;
    n = n->next_node;

  }

  return size;
}


// Stack functions

// mallocing a stack and adding nodes to it
stack* create_stack(int s){

  stack* stack_ptr = (stack*)malloc(sizeof(stack));

  stack_ptr->head_node = NULL;

  stack_ptr->size = s;

  for(int i = 1; i <= stack_ptr->size; i++){
    double_linked_list_node* n = (struct double_linked_list_node*)malloc(sizeof(double_linked_list_node));
    
    n->number = i;

    if(stack_ptr->head_node == NULL){
       
      n->previous_node = NULL;

      stack_ptr->head_node = n;


    }else{

      double_linked_list_node* p = stack_ptr->head_node;

      while(p ->next_node != NULL){

        p = p->next_node;

      }

      p->next_node = n;
      n->previous_node = p;


    }


  }

  return stack_ptr;
}


//returning the head node
double_linked_list_node* get_stack_top(stack* s){

  double_linked_list_node* n = s->head_node;

  return n;

}

//removing the head node
void pop(stack* s){

  if(!s->head_node){

    printf("The head node is already deleted \n");

    return;

  }else{

    double_linked_list_node* n = s->head_node;

    if(s->head_node->next_node == NULL){

      free(s->head_node);

      return;

    }else{

       n->next_node->previous_node = NULL;

      while(n->next_node != NULL){

        n->number = n->next_node->number;

        n = n->next_node;

     }

      free(n);

      return;
    }

  }

}

//adding a node to the top of the list, making it hte new head node
void push(stack* s, int element){

  double_linked_list_node* n = (struct double_linked_list_node*)malloc(sizeof(double_linked_list_node));
  n->number = element;
  n->previous_node = NULL;

  double_linked_list_node* extra = s->head_node;

  n->next_node = extra;

  extra->previous_node = n;

  s->head_node = n;

}

//queue
//mallocing a queue struct and adding nodes to it
queue* create_queue(int s){

  queue* queue_ptr = (queue*)malloc(sizeof(queue));

  queue_ptr -> top_node = NULL;
  queue_ptr -> tail_node = NULL;

  queue_ptr->size = s;

  for(int i = 1; i <= queue_ptr->size; i++){

    double_linked_list_node* n = (struct double_linked_list_node*)malloc(sizeof(double_linked_list_node));

    n->number = i;

    if(i == 1){
       
       printf("setting first node in q \n");

       n->previous_node = NULL;

      queue_ptr->top_node = n;

    }else if(i == queue_ptr->size){
      
      double_linked_list_node* p = queue_ptr->top_node;

      while(p ->next_node != NULL){
        
        p = p->next_node;
        
      }
      
      queue_ptr->tail_node = p->next_node;
      printf("setting last node in q\n");
      queue_ptr->tail_node = n;
      
      queue_ptr->tail_node->previous_node = p;


    }else{

      double_linked_list_node* p = queue_ptr->top_node;

      while(p ->next_node != NULL){
        p = p->next_node;
        
      }

      p->next_node = n;
      n->previous_node = p;


    }



  }

  return queue_ptr;


}

// returning the top node
double_linked_list_node* get_queue_top(queue* q){

double_linked_list_node* n = q->top_node;

return n;

}

//removing the head node and replacing it
void queue_pop(queue* q){

  if(q->top_node == NULL){

      printf("The head node is already deleted \n");

      return;

  }else{

    double_linked_list_node* n = q->top_node;

    if(q->top_node->next_node == NULL){
      free(q->top_node);
      return;

    }else{

       n->next_node->previous_node = NULL;
     

      while(n->next_node != NULL){

       n->number = n->next_node->number;

       n = n->next_node;

     }


      free(n);

      return;
    }

  }

}

//putting a node at the end of the list, making it the tail node
void queue_push(queue* q, int element){

  double_linked_list_node* n = (double_linked_list_node*)malloc(sizeof(double_linked_list_node));

  double_linked_list_node* extra;

  n->number = element;

  extra = q->tail_node;

  extra ->next_node = n;

  n->previous_node = extra;

  q->tail_node = n;

}